$(document).ready(function(){
	$('.custom_slick').slick({
		infinite: true,
		slidesToShow: 2,
		slidesToScroll: 3,
		arrows: true
	});
});

